import mininet.net

net.get("h1").setIP("10.10.10.1",24)
net.get("h2").setIP("10.10.10.2",24)
net.get("h3").setIP("10.10.10.3",24)
net.get("h4").setIP("10.10.10.4",24)

