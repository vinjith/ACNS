from mininet.topo import Topo
import mininet.net  

class MyTopo( Topo ):
    

    def __init__( self ):
         

        # Initialize topology
        Topo.__init__( self )
         
        #net = mininet() 
        # Add hosts and switches
        Host1 = self.addHost( 'host1' )
	Host2 = self.addHost( 'host2' )
	Host3 = self.addHost( 'host3' )
        Server5 = self.addHost( 'server5' )
		
        Switch = self.addSwitch( 's3' )

        # Add links
        self.addLink( Host1, Switch )
	self.addLink( Host2, Switch )
	self.addLink( Host3, Switch )
	self.addLink( Host4, Switch )

topos = { 'mytopo': ( lambda: MyTopo() ) }
