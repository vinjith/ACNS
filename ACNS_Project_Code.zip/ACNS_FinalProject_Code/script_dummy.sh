#!/bin/bash

#Add a bridge
#sudo ovs-vsctl add-br br0

#Attach the ports to bridge br0
#sudo ovs-vsctl add-port br0 s1-eth1
#sudo ovs-vsctl add-port br0 s1-eth2

#Add a dummy port to direct the traffic to implement SPAN mirroring
sudo modprobe dummy
sudo ip link set up dummy0

#Add dummy port to br0
sudo ovs-vsctl add-port s1 dummy0

#Store the UID of mirroring command to variable
sudo ovs-vsctl \
-- --id=@m create mirror name=mirror0 \
-- add bridge s1 mirrors @m
 
#Find UUID of target interface
sudo ovs-vsctl list port dummy0 | awk '{print $3}'> "log.txt" 2>&1
UID_BR=$(sudo head -1 log.txt)

echo $UID_BR

#Configure mirror to output mirrored pasckets to target interface
sudo ovs-vsctl set mirror mirror0 \
output_port=$UID_BR

#Find UUID of port whose packets should be mirrored
sudo ovs-vsctl list port s1-eth1 | awk '{print $3}'> "log.txt" 2>&1
uid_eth1=$(sudo head -1 log.txt)

echo $uid_eth1

sudo ovs-vsctl list port s1-eth2 | awk '{print $3}'> "log.txt" 2>&1
uid_eth2=$(sudo head -1 log.txt)

echo $uid_eth2

sudo ovs-vsctl list port s1-eth3 | awk '{print $3}'> "log.txt" 2>&1
uid_eth3=$(sudo head -1 log.txt)

echo $uid_eth3

sudo ovs-vsctl list port s1-eth4 | awk '{print $3}'> "log.txt" 2>&1
uid_eth4=$(sudo head -1 log.txt)

echo $uid_eth4

#Mirror packets sent to and received from interface of interest
sudo ovs-vsctl set mirror mirror0 \
         select\_dst\_port=$UID_BR

sudo ovs-vsctl set mirror mirror0 \
         select\_src\_port=$uid_eth1

sudo ovs-vsctl set mirror mirror0 \
         select\_src\_port=$uid_eth2
         
sudo ovs-vsctl set mirror mirror0 \
         select\_src\_port=$uid_eth3

sudo ovs-vsctl set mirror mirror0 \
         select\_src\_port=$uid_eth4         
                           
#All switch packets go to dummy0
 sudo ovs-vsctl set mirror mirror0 select_all=1
