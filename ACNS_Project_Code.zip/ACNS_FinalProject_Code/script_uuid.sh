#Clean up
sudo ovs-vsctl del-port s1 s1-eth1
sudo ovs-vsctl del-port s1 s1-eth2
sudo ovs-vsctl del-port s1 s1-eth3
sudo ovs-vsctl del-port s1 s1-eth4
sudo ovs-vsctl del-br s1
