#!/usr/bin/python

import re
from pprint import pprint

dict = {}
def snort_parse(logfile):
    
    f_open = open(logfile,"r")
    str=f_open.readlines()
    
    for i in range(len(str)):
        
        if "TCP" in str[i]:
           #print(str[i])
           str[i]=re.sub(":\d+","",str[i])        
	if "Possible" in str[i]: 
           regex= re.split("[' ','\n']",str[i])
           if "{ICMP}" not in str[i]:
              dict[regex[13]]=i;
              dict[regex[15]]=i;
	   #print(regex[13])  
                
    for key in dict.iterkeys():
        print key
  
    #pprint(dict)            
snort_parse('/var/log/asv.log')
