sudo mn --topo --custom mininet.py --switch ovsk --controller remote --test cli
